The submission should contain the following items:

1. results.txt
    A plain text file. Each line begins with an image id (as in ./list/ of the LV-MHP-V2 dataset), followed by multiple pairs of person id and confidence score. Person ids range from 1 to the total number of persons, and confidence scores are used to rank the person instances. The separator is a space.

2. global_seg/
    A folder of png images. For an image id in results.txt, there should be a file named id.png under this folder. The content of id.png is the global person parsing results (instance-agnostic) for the image with exactly the same size. Then id.png file contains integer values 0,1,2,..58, following the same category definition in the README file of LV-MHP-V2. 

3. global_tag/
    A folder of png images. For an image id in results.txt, there should be a file named id.png under this folder. The content of id.png is the person instance map for the image with exactly the same size. Then id.png file contains integer values 0,1,2,..Inf, where 0 indicates background, 1 indicates the person with person id 1 in results.txt, 2 indicates person id 2, and so on. 
